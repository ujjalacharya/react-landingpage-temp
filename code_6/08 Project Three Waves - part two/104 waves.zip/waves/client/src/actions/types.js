export const LOGIN_USER = 'login_user';
export const REGISTER_USER = 'register_user';
export const AUTH_USER = 'auth_user';
export const LOGOUT_USER = 'logout_user';

export const GET_PRODUCTS_BY_SELL = 'get_products_by_sell';
export const GET_PRODUCTS_BY_ARRIVAL = 'get_products_by_arrival';
