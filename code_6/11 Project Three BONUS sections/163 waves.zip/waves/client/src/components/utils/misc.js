// SERVER ROUTES
export const USER_SERVER = '/api/users';
export const PRODUCT_SERVER = '/api/product';
export const SITE_SERVER = '/api/site';