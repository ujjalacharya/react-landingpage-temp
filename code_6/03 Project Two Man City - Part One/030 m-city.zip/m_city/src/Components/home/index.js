import React from 'react';
import Featured from './featured';

const Home = () => {
    return (
        <div className="bck_blue">
            <Featured/>
        </div>
    );
};

export default Home;