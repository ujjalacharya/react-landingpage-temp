import React from 'react';
import Layout from './Hoc/Layout';

const Routes = (props) => {
  return(
    <Layout>
      second line
    </Layout>
  )
}

export default Routes;
