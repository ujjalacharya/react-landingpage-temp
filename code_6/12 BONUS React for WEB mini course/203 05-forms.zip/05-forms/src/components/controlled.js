import React, { Component } from 'react';

class Controlled extends Component {

    state = {
        
    }

    render(){
        return(
            <div>
                Controlled
            </div>
        )
    }
}

export default Controlled;