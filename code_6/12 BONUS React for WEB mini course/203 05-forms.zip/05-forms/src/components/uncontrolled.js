import React, { Component } from 'react';

class Uncontrolled extends Component {

    state = {

    }

    render(){
        return(
            <div>
                Uncontrolled
            </div>
        )
    }
}

export default Uncontrolled;