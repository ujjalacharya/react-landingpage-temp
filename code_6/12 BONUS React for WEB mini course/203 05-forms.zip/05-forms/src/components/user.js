import React, { Component } from 'react';

class User extends Component {

    state = {
        
    }

    render(){
        return(
            <div>
                User
            </div>
        )
    }
}

export default User;