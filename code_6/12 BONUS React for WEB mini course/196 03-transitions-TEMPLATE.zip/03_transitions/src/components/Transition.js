import React, { Component } from 'react';
import '../css/App.css';

class TransitionComp extends Component{

    render(){
        return(
            <div>
                Transition
            </div>

        )
    }
}


export default TransitionComp;