import React, { Component } from 'react';

import '../css/App.css';

class Fade extends Component{
    render(){
        return(
            <div>
                CSS TRANSITIONS
            </div>
        )
    }
}


export default Fade;